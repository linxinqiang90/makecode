# Name Tag

Scroll your name across the screen.

```blocks
basic.forever(() => {
    basic.showString("JAMES")
})
```