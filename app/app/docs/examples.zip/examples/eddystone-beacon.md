# Eddystone Beacon

```blocks
led.enable(false)
bluetooth.advertiseUrl(
    "https://makecode.com",
    7,
    false
)
```

```package
device
```
