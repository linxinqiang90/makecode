# Turtle Square

A turtle that traces a square pattern.

```blocks
turtle.setPosition(0, 0)
turtle.turnRight()
turtle.setSpeed(29)
basic.forever(() => {
    turtle.forward(4)
    turtle.turnRight()
})
```

```package
microturtle=github:Microsoft/pxt-microturtle#master
```
